package lmao;

public class Launch {

	public static void main(String[] args) {

		System.out.println("okay, wer liest sich das durch?");

	}

}
