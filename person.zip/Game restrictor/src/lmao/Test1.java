package lmao;

public class Test1 {

}
